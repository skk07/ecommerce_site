function updateDashboard() {
    const startDate = document.getElementById('start-date').value;
    const endDate = document.getElementById('end-date').value;
    document.getElementById('start-date-text').innerText = startDate;
    document.getElementById('end-date-text').innerText = endDate;
    document.getElementById('start-date-text-2').innerText = startDate;
    document.getElementById('end-date-text-2').innerText = endDate;

    // Update sales chart with dummy data
    const ctx = document.getElementById('salesChart').getContext('2d');
    const salesChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['May 24', 'May 25', 'May 26', 'May 27', 'May 28'],
            datasets: [{
                label: 'Sales',
                data: [0.5, 1.0, 0.3, 0.7, 0.2],
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}
