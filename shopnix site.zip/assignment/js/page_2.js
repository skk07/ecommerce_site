document.addEventListener("DOMContentLoaded", function() {
    var progressMessage = document.getElementById("progressMessage");

    // Change message after 3 seconds
    setTimeout(function() {
        progressMessage.textContent = "Step 1 : Creating Store";
    }, 3000);

    // Show second popup after 5 seconds
    setTimeout(function() {
        document.getElementById("secondPopup").style.display = "block";
    }, 5000);

    // Close button functionality for both popups
    var closeBtns = document.querySelectorAll(".close-btn");
    closeBtns.forEach(function(btn) {
        btn.addEventListener("click", function() {
            document.querySelector(".popup-wrapper").style.display = "none";
            document.getElementById("secondPopup").style.display = "none";
        });
    });

    // Button functionality for second popup
    var btnUpdatePassword = document.querySelector(".btn-update-password");
    btnUpdatePassword.addEventListener("click", function() {
        alert("Updating password...");
        // Add your logic for updating password here
        // For demo, moving to the next page after 1 second
        setTimeout(function() {
            window.location.href = "page_3.html";
        }, 1000);
    });

    var btnNotNow = document.querySelector(".btn-not-now");
    btnNotNow.addEventListener("click", function() {
        // For demo, moving to the next page after 1 second
        setTimeout(function() {
            window.location.href = "page_3.html";
        }, 1000);
    });
});