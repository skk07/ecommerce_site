$(document).ready(function () {
    // Initialize Quill editor
    var quill = new Quill('#productDescription', {
        theme: 'snow',
        modules: {
            toolbar: [
                ['bold', 'italic', 'underline', 'strike'],
                [{ 'font': [] }, { 'size': [] }],
                [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                ['clean']
            ]
        }
    });

    function updateDisplay() {
        const productName = $('#productName').val();
        const productDescription = quill.root.innerHTML;
        const listPrice = parseFloat($('#listPrice').val()) || 0;
        const discountPercentage = parseFloat($('#discountPercentage').val()) || 0;
        const gstRate = parseFloat($('#gstRate').val()) || 0;
        const shippingCharges = parseFloat($('#shippingCharges').val()) || 0;

        let netPrice = listPrice;

        if (discountPercentage > 0) {
            netPrice = netPrice - (netPrice * (discountPercentage / 100));
        }

        if ($('#gstIncluded').is(':checked') && gstRate > 0) {
            const gstAmount = netPrice * (gstRate / 100);
            netPrice = netPrice + gstAmount;
        }

        if (shippingCharges > 0) {
            netPrice = netPrice + shippingCharges;
        }

        $('#displayProductName').text(productName);
        $('#displayProductDescription').html(productDescription);
        $('#displayListPrice').text(listPrice.toFixed(2));
        $('#displayNetPrice').text(netPrice.toFixed(2));

        const file = $('#productImage')[0].files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function (e) {
                $('#displayProductImage').attr('src', e.target.result).show();
            }
            reader.readAsDataURL(file);
        } else {
            $('#displayProductImage').hide();
        }

        // Update net price in the form
        $('#netPrice').val(netPrice.toFixed(2));
    }

    // Update display in real-time
    $('#productName, #listPrice, #discountPercentage, #gstRate, #shippingCharges').on('input', updateDisplay);
    quill.on('text-change', updateDisplay);
    $('#productImage').on('change', updateDisplay);

    $('#nextBtn, #backBtn').click(function() {
        // Validate form before redirecting
        if ($('#product-form')[0].checkValidity()) {
            // Redirect to the next or previous page
            window.location.href = $(this).attr('href');
        } else {
            alert('Please fill in all required fields.');
        }
    });

    // $('#product-form').on('submit', function(e) {
    //     e.preventDefault();
    //     if ($('#product-form')[0].checkValidity()) {
    //         alert('Form submitted successfully!');
    //         // Perform any additional submission logic if needed
    //     } else {
    //         alert('Please fill in all required fields.');
    //     }
    // });

    $('#product-form').on('submit', function(e) {
        e.preventDefault(); // Prevent default form submission
    
        let isValid = true;
    
        // Check if all required fields are filled
        $('#product-form input[required]').each(function() {
            if (!this.value.trim()) {
                isValid = false;
                $(this).addClass('is-invalid');
            } else {
                $(this).removeClass('is-invalid');
            }
        });
    
        // Custom validation for Quill editor
        if (quill.getText().trim().length === 0) {
            isValid = false;
            $('#productDescription').addClass('is-invalid');
        } else {
            $('#productDescription').removeClass('is-invalid');
        }
    
        if (isValid) {
            alert('Form submitted successfully!');
            // Perform any additional submission logic if needed
        } else {
            alert('It is mandatory to fill all required fields.');
        }
    });
    
});