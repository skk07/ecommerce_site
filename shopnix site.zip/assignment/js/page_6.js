$(document).ready(function () {
    function updateDisplay() {
        const storeName = $('#storeName').val();
        const storeTitle = $('#storeTitle').val();
        const supportEmail = $('#supportEmail').val();
        const supportPhone = $('#supportPhone').val();

        $('#displayStoreName').text(storeName);
        $('#displayStoreTitle').text(storeTitle);
        $('#displaySupportEmail').text(supportEmail);
        $('#displaySupportPhone').text(supportPhone);

        const logoFile = $('#storeLogo')[0].files[0];
        if (logoFile) {
            const reader = new FileReader();
            reader.onload = function (e) {
                $('#displayLogo').attr('src', e.target.result).show();
            }
            reader.readAsDataURL(logoFile);
        } else {
            $('#displayLogo').hide();
        }
    }

    function validateForm() {
        let isValid = true;
        $('#customize-form input').each(function() {
            if (!this.checkValidity()) {
                $(this).addClass('is-invalid');
                isValid = false;
            } else {
                $(this).removeClass('is-invalid');
            }
        });
        return isValid;
    }

    $('#customize-form input, #customize-form textarea').on('input change', function() {
        $(this).removeClass('is-invalid');
        updateDisplay();
    });

    $('#reviewButton').click(function() {
        if (validateForm()) {
            alert('Form is valid and ready for review.');
        } else {
            alert('Please fill in all required fields.');
        }
    });

    $('#customize-form').on('submit', function(e) {
        e.preventDefault();
        if (validateForm()) {
            alert('Form submitted successfully!');
        } else {
            alert('Please fill in all required fields.');
        }
    });
});