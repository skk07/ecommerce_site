document.addEventListener("DOMContentLoaded", function() {
    // Function to handle marking selection
    function handleChooseButtonClick(event) {
        var allChooseBtns = document.querySelectorAll(".choose-btn");
        allChooseBtns.forEach(function(btn) {
            btn.innerText = "Choose"; // Reset all buttons to "Choose"
        });
        event.target.innerText = "✔"; // Set clicked button text to tick mark
        event.target.classList.add("btn-success"); // Optionally add success class for styling
    }

    // Attach click event listener to all choose buttons
    var chooseButtons = document.querySelectorAll(".choose-btn");
    chooseButtons.forEach(function(btn) {
        btn.addEventListener("click", handleChooseButtonClick);
    });
});