document.getElementById('nextBtn').addEventListener('click', function () {
    var productType = document.getElementById('productType').value;

    if (!productType) {
        alert('Please fill in the Product Type.');
        return;
    }

    // If the form is valid, proceed to the next page
    window.location.href = 'page_5.html';
});