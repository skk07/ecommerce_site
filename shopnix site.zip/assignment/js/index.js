// Timer countdown function
function startTimer(duration, display) {
    var timer = duration, minutes, seconds;
    setInterval(function () {
        minutes = parseInt(timer / 60, 10);
        seconds = parseInt(timer % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.textContent = "Resend OTP in " + minutes + ":" + seconds;

        if (--timer < 0) {
            timer = duration;
        }
    }, 1000);
}

document.addEventListener("DOMContentLoaded", function() {
    var timerDisplay = document.getElementById("timer");
    startTimer(120, timerDisplay); // 120 seconds = 2 minutes

    // Edit Mobile functionality (just a demo, not functional in this example)
    var editMobileLink = document.getElementById("editMobile");
    editMobileLink.addEventListener("click", function() {
        alert("Edit Mobile link clicked!");
        // Add your logic here for editing mobile number
    });

    // Lets Go button functionality (just a demo, not functional in this example)
    // var letsGoBtn = document.getElementById("letsGoBtn");
    // letsGoBtn.addEventListener("click", function() {
    //     alert("Let's Go button clicked!");
    //     // Add your logic here for proceeding after OTP verification
    //     // For demo, closing the popup
    //     document.querySelector(".popup-wrapper").style.display = "none";
    // });

    // Close button functionality
    var closeBtn = document.querySelector(".close-btn");
    closeBtn.addEventListener("click", function() {
        document.querySelector(".popup-wrapper").style.display = "none";
    });
});